Cambridge B1 Preliminary for Schools Trainer (Exam Practice only)

Prepared for WordHop repository funghwang99/wordhop
Source: user-provided TRAINER(1).pdf
All images are real scanned pages from the book. Tests 1 and 2 omit every Training page.
Assets: dist/assets/{reading,writing,listening,speaking}/trainer-t*.webp
Manifest: dist/trainer/exam-pages.json
No audio included.
